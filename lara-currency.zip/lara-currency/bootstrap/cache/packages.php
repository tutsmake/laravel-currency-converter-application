<?php return array (
  'ashallendesign/laravel-exchange-rates' => 
  array (
    'providers' => 
    array (
      0 => 'AshAllenDesign\\LaravelExchangeRates\\Providers\\ExchangeRatesProvider',
    ),
  ),
  'danielme85/laravel-cconverter' => 
  array (
    'providers' => 
    array (
      0 => 'danielme85\\CConverter\\CConverterServiceProvider',
    ),
    'aliases' => 
    array (
      'Currency' => 'danielme85\\CConverter\\CConverter',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'torann/currency' => 
  array (
    'providers' => 
    array (
      0 => 'Torann\\Currency\\CurrencyServiceProvider',
    ),
    'aliases' => 
    array (
      'Currency' => 'Torann\\Currency\\Facades\\Currency',
    ),
  ),
);